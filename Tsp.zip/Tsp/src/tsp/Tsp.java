
package tsp;

import java.util.ArrayList;
import java.util.List;
//import java.util.Random;
import java.io.*;
import java.util.*;

public class Tsp {
    public static void main(String[] args){
        List<ciudad> lista = new ArrayList<ciudad>();
        int nomCiudad, x, y;
        double menorCamino = 900000.0;
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        long time_start, time_end;
        time_start = System.currentTimeMillis();
      try {
         // Apertura del fichero y creacion de BufferedReader para poder
         // hacer una lectura comoda (disponer del metodo readLine()).
         archivo = new File ("prueba.txt");
         fr = new FileReader (archivo);
         br = new BufferedReader(fr);
 
         // Lectura del fichero
         String linea;
         while((linea=br.readLine())!=null)
         {
             StringTokenizer mistokens = new StringTokenizer(linea, " ");
             while(mistokens.hasMoreTokens())
             {
                 nomCiudad = Integer.parseInt(mistokens.nextToken());
                 x = Integer.parseInt(mistokens.nextToken());
                 y = Integer.parseInt(mistokens.nextToken());
                 lista.add(new ciudad(nomCiudad,x,y));
                 
             }
         }
      }
      catch(Exception e){
         e.printStackTrace();
      }finally{
         // En el finally cerramos el fichero, para asegurarnos
         // que se cierra tanto si todo va bien como si salta 
         // una excepcion.
         try{                    
            if( null != fr ){   
               fr.close();     
            }                  
         }catch (Exception e2){ 
            e2.printStackTrace();
         }
      }
        
        PermutacionesIterator iter = new PermutacionesIterator(lista);
        while (iter.hasNext()){
            TspSol sol = new TspSol(iter.next(), 0);
            //System.out.println(sol);
            if(sol.getFitness()<menorCamino)
            {
                menorCamino = sol.getFitness();
                System.out.println(sol);
            }
                
        }
        System.out.println("El ultimo camino impreso es el camino minimo para el archivo de texto");
        time_end = System.currentTimeMillis();
        System.out.println("La tarea toma "+(time_end-time_start)+" milliseg");
    }
    
}