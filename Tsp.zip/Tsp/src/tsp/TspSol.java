/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tsp;

import java.util.List;


public class TspSol {
    
    private List<ciudad> ciudades;
    private double camino;

    public TspSol(List<ciudad> ciudades, double camino) {
        this.ciudades = ciudades;
        this.camino = camino;
    }
    
    public double getCamino() {
        return this.camino;
    }

    public void setCamino(double x) {
        this.camino = ciudades.get(0).distancia(ciudades.get(ciudades.size()-1));
    }

    @Override
    public String toString() {
        return "TspSol {"+ciudades +"} ="+this.getFitness();
    }
    
    public double getFitness(){
        double salida =0.0;
        
        for (int i=0; i < ciudades.size()-1; i++){
            salida += ciudades.get(i).distancia(ciudades.get(i+1));
        }
        
        salida += ciudades.get(0).distancia(ciudades.get(ciudades.size()-1));
        this.camino = salida;
        
        return salida;
    }
    
    
}